<?php
echo 'Hello World' . "<br>";
echo $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['SERVER_NAME'];
?>